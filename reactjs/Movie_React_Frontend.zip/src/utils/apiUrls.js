export const apiUrls = {
      //image upload
      uploadFiles: 'admin/uploadImageArr',
      //login
      login: 'admin/login',
      //movie list
      movielist:'admin/movie',
      //movie create
      create:'admin/movie/store',
      //movie Detiels
      view:'admin/movie',
         //movie Update
      update:'admin/movie/update'
};
