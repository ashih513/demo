import React, { Suspense, Fragment, lazy } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Authenticated from './Guard/Authenticated';
import Guest from './Guard/Guest';

const BaseLayout = (props)=>{
  return(props.children);
}

export function RenderRout() {
  
  
    return (
      <>
       <Router>
          <Suspense fallback={<div>........</div>}
          >
              <Routes>
              {routes?.map((route, i) => {
                const Guard = route?.guard || Fragment;
                const Layout = route?.layout || Fragment;
                const Component = route?.element;
                return (
                  <Route
                    key={i}
                    path={route.path}
                    exact={route.exact}
                    element={
                      <Guard>
                        <Layout >
                          <Component />
                          </Layout>
                      </Guard>
                    }
                  />
                );
              })}
            </Routes>
          </Suspense>
        </Router>
         </>
    )
  
  }

  const routes = [

    // Login 
    {
      guard: Guest,
      layout:BaseLayout,
      exact: true,
      path: '/',
      element: lazy(() => import('./Auth/Login'))
    },
   
    //movie
    {
      guard: Authenticated,
      layout:BaseLayout,
      exact: true,
      path: '/movie-list',
      element: lazy(() => import('./Component/Movies/Index'))
    },

    {
      guard: Authenticated,
      layout:BaseLayout,
      exact: true,
      path: '/add-movie',
      element: lazy(() => import('./Component/Movies/AddMovie'))
    },


    {
      guard: Authenticated,
      layout:BaseLayout,
      exact: true,
      path: '/edit-movie',
      element: lazy(() => import('./Component/Movies/EditMovie'))
    },

    {
      guard: Guest,
      layout:BaseLayout,
      exact: true,
      path: '*',
      element: lazy(() => import('./Component/Movies/Index'))
    },

   

    
    
]