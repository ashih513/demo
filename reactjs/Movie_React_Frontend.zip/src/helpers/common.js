import React from 'react';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
const ApiLoder = () => {
  return (
    <>
      <div className='spinner_overlay'></div>
      <div className="spinner-box">
        <div className="loading-icon">
        </div>
      </div>
    </>

  );
}

const AcceptImageType = 'image/png,image/jpg,image/jpeg'
const ImageType = ["image/png", "image/jpg", "image/jpeg"]




const SuccessMessage = (message) => {
  setTimeout(() => toast.success(message, {
    position: "top-center",
    autoClose: 2000,
    theme: "colored",
    hideProgressBar: false,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
  }), 10)
}

const ErrorMessage = (message) => {
  toast.error(message, {
    position: "top-center",
    autoClose: 2000,
    theme: "colored",
    hideProgressBar: false,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
  });
}



export { ApiLoder,AcceptImageType,ImageType,SuccessMessage,ErrorMessage }
