import React, {useRef, useState } from 'react'
import {useNavigate} from 'react-router-dom'
import { callAPIWithoutAuth } from '../utils/apiUtils'
import { apiUrls } from '../utils/apiUrls'
import { ErrorMessage, SuccessMessage } from '../helpers/common'
import SimpleReactValidator from 'simple-react-validator';

export default function Login() {
  const [value, setValue] = useState({email:"",password:""})
  const [loader, setloader] = useState(false)
  const navigate = useNavigate()
  const simpleValidator = useRef(new SimpleReactValidator());
  const [, forceUpdate] = useState();
  
  const Login = async () => {
    try {
      setloader(true)
      const response = await callAPIWithoutAuth(apiUrls.login, {}, 'POST', value)
      setloader(false)
      if(response.data.status){
        let datas=response?.data?.data;
        localStorage.setItem('accessToken',datas?.token)
         localStorage.setItem('userData',JSON.stringify(datas?.user))
        SuccessMessage(response.data.message)
        navigate('/movie-list')
      } else{
        ErrorMessage(response.data.message)
      }
    } catch (e) {
      setloader(false)
      ErrorMessage(e.message)
    }
  }

  const handleChange = (e) => {
    setValue((val)=>{return {...val, [e.target.name]:e.target.value}})
  }

  

  const handleSubmit = (e) => {
    e.preventDefault(); 
    const formValid = simpleValidator.current.allValid();
    if (!formValid) {
      simpleValidator.current.showMessages();
      forceUpdate(1)
    } else {
      Login();
    }
     
  }


 return  (
  <>
  <div className="movie-div">
  <div className="signup">
    <h1>Sign in</h1>
    <form onSubmit={handleSubmit}>
    <div className="form-group">
      <input type="text" className="form-control" placeholder="Email"    name='email'
                          value={value?.email}
                          onChange={handleChange}/>
                          <div className="error">{simpleValidator.current.message('Email', value?.email, 'required|email')}</div>
    </div>
    <div className="form-group">
      <input type="text" className="form-control" placeholder="Password"   name='password'
                          value={value?.Password}
                          onChange={handleChange}/>
                          <div className="error">{simpleValidator.current.message('Password', value?.password, 'required')}</div>
    </div>
    <div className="form-group form-check d-flex align-items-center justify-content-center gap-2">
      <input type="checkbox" className="form-check-input" id="exampleCheck1" />
      <label className="form-check-label" htmlFor="exampleCheck1">
        Check me out
      </label>
    </div>
    <div className="form-group">
      <button type='submit' disabled={loader} className="btn brand-btn" >
        Login
      </button>
    </div>
    </form>
  </div>
</div>
  </>
  
  ) 
}
