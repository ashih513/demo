import React, { useEffect, useState } from "react";
import NomovieFound from "./NomovieFound";
import { callAPI } from "../../utils/apiUtils";
import { apiUrls } from "../../utils/apiUrls";
import { ApiLoder, ErrorMessage } from "../../helpers/common";
import PageTitle from "./PageTitle";
import { defaultConfig } from "../../config";
import { useNavigate } from "react-router-dom";

export default function Index() {
  const [loder, setLoader] = useState(false);
  const [movieList, setMovieList] = useState([]);
  const navigate = useNavigate()

  const MovieListAPI = async () => {
    setLoader(true);
    try {
      const apiResponse = await callAPI(apiUrls.movielist, {}, "GET");
      if (apiResponse?.data?.status === true) {
        if (apiResponse?.data?.data?.movies?.length > 0) {
          setMovieList(apiResponse?.data?.data?.movies);
        }
      } else {
        ErrorMessage(apiResponse?.data?.message);
      }
      setLoader(false);
    } catch (error) {
      setLoader(false);
      ErrorMessage(error?.message);
    }
  };

  useEffect(() => {
    MovieListAPI();
  }, []);
  return (
    <>
      {loder && <ApiLoder />}
      
      { movieList.length > 0 ? (
        <div className="movie-div">
          <section>
            <div className="container small-container">
              <div className="create-movie">
                <PageTitle />
                <div className="movie-list">
                  <div className="row">
                    {movieList !== undefined &&
                      movieList.length > 0 &&
                      movieList.map((val, i) => (
                        <div className="col-lg-3" key={i} onClick={(()=>navigate('/edit-movie?id=' + val._id))} style={{ cursor:'pointer' }}>
                          <div className="movie-item">
                            <img
                              src={defaultConfig.imagePath + val?.image}
                              className="img-fluid"
                              alt=""
                            />
                            <div className="movie-name">
                              <h6>{val?.title}</h6>
                              <p>{val?.publishYear}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              </div>
              <div className="empty-div" />
            </div>
          </section>
        </div>
      ) : (
        !loder && <NomovieFound />
      )}
    </>
  );
}
