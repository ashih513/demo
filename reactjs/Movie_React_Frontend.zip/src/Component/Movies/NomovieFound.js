import React from 'react'
import { useNavigate } from 'react-router-dom'


export default function NomovieFound() {
    const navigate=useNavigate();
  return (
    <>
    <div className="movie-div">
  <div className="signup w-auto empty text-center">
    <h2>Your movie list is empty</h2>
    <div className="form-group">
      <button type="button" className="btn brand-btn" onClick={(()=>navigate('/add-movie'))}>
        Add a new movie
      </button>
    </div>
  </div>
</div>

   
    </>
  )
}
