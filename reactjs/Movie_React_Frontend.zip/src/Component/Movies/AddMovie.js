import React, { useRef, useState } from 'react'
import { PostImage } from '../../utils/apiCall';
import { AcceptImageType,ErrorMessage, ImageType, SuccessMessage } from '../../helpers/common';
import { callAPI } from '../../utils/apiUtils';
import { apiUrls } from '../../utils/apiUrls';
import { useNavigate } from 'react-router-dom';
import SimpleReactValidator from 'simple-react-validator';

export default function AddMovie() {
    const [value, setValue] = useState({title:'',image:'',publishYear:''});
    const [image, setImage] = useState('');
    const [loder,setLoader]=useState(false)
    const simpleValidator = useRef(new SimpleReactValidator());
    const [, forceUpdate] = useState();
    const navigate = useNavigate()
    const handleChange = (e) => {
        setValue((val) => {
          return { ...val, [e.target.name]: e.target.value };
        });
      };

      const UploadImage = async (e,allowedFileTypes) => {
        let file = (e?.target?.files[0])
        let name = e?.target?.name;
        if ((allowedFileTypes.includes(file?.type) || allowedFileTypes.includes(file?.name?.split('.').reverse()[0]))) {
          setImage(file)
          const path = await PostImage(file);
          if (path?.length > 0) {
            setValue((val) => {
                return { ...val, [name]: path[0] };
              });
          }
          e.target.value = null
        } else {
          ErrorMessage("Invalid file Formate")
          e.target.value = null
          return false
        }
      }

      const movieAdd = async () => {
        try {
            setLoader(true)
            const apiResponse = await callAPI(apiUrls.create,{},"POST",value);
            if (apiResponse?.data?.status === true) {
                SuccessMessage(apiResponse?.data?.message)
                navigate(`/movie-list`)

            } else {
                ErrorMessage(apiResponse?.data?.message)
            }
            setLoader(false)
        } catch (error) {
            setLoader(false)
            ErrorMessage(error?.message)
        }
    }

    const handleSubmit = (e) => {
        e.preventDefault(); 
        const formValid = simpleValidator.current.allValid();
        if (!formValid) {
          simpleValidator.current.showMessages();
          forceUpdate(1)
        } else {
            movieAdd();
        }
         
      }
      const RemoveImage =()=>{
        setImage('')
        setValue((val) => {
          return { ...val, ['image']:'' };
        });
      }
  return (
    <>
    <div className="movie-div">
  <section>
    <div className="container small-container">
      <div className="create-movie">
        <div className="empty">
          <h2>Create a new movie</h2>
        </div>
        
        <div className="row">
          
          
          <div className="drag-drop d-flex align-items-center justify-content-center">
            <div className="text-icon">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="d-block mx-auto"
                width={24}
                height={24}
                viewBox="0 0 24 24"
                fill="none"
              >
                <g clipPath="url(#clip0_3_346)">
                  <path
                    d="M18 15V18H6V15H4V18C4 19.1 4.9 20 6 20H18C19.1 20 20 19.1 20 18V15H18ZM17 11L15.59 9.59L13 12.17V4H11V12.17L8.41 9.59L7 11L12 16L17 11Z"
                    fill="white"
                  />
                </g>
                <defs>
                  <clipPath id="clip0_3_346">
                    <rect width={24} height={24} fill="white" />
                  </clipPath>
                </defs>
              </svg>
              <input type='file' name='image' accept={AcceptImageType} onChange={(e) => { UploadImage(e,ImageType)}}/>
              Drop an image here
            </div>
         
            <div className="error">{simpleValidator.current.message('Image', value?.image, 'required')}</div>
          </div>
          <figure className='uploadimg position-relative'>
          {
                image &&
                <>
                  <img src={URL.createObjectURL(image)} alt='jj'/>
                  <img src='/image/close.svg' className='close_svg' alt='jj' onClick={RemoveImage}/>
                </>
              
              }
            
          </figure>
          <div className="drag-drop-form">
            <div className="signup">
             
         
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="title"
                  onChange={handleChange}
                  value={value.title}
                  name='title'
                />
                  <div className="error">{simpleValidator.current.message('Title', value?.title, 'required')}</div>
              </div>
              <div className="form-group publised">
                <input
                  type="text"
                  onChange={handleChange}
                  value={value.publishYear}
                  name='publishYear'
                  className="form-control"
                  placeholder="Publishing year"
                />
                  <div className="error">{simpleValidator.current.message('Publishing year', value?.publishYear, 'required|numeric|min:4|max:4')}</div>
              </div>
              <div className="form-group d-flex gap-3">
                <button
                  type="button"
                  className="btn brand-btn brand-btn-border"
                  onClick={(()=>  navigate(`/movie-list`))}
                >
                  Cancel
                </button>
                <button type="button" onClick={handleSubmit} disabled={loder} className="btn brand-btn">
                  Submit
                </button>
              </div>
            </div>
          </div>
         
        </div>
      
      </div>
      <div className="empty-div" />
    </div>
  </section>
</div>

    
        

        
   
    </>
  )
}
