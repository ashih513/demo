import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { removeAuth } from '../../helpers/auth';

export default function PageTitle() {
    const navigate=useNavigate();
    const Logout = ()=>{
        navigate('/')
        removeAuth(); 
    }
  return (
    <>
     <div className="empty">
          <h2 className="d-flex align-items-center justify-content-between">
            <span className="d-flex align-items-center gap-2">
              My movies{" "}
              <Link to="/add-movie">
                <img src="image/add-plus.svg" alt="" srcSet="" />
              </Link>
            </span>
            <span className="d-flex align-items-center gap-2 logout" onClick={Logout}>
              Logout{" "}
              <Link>
                <img src="/image/logout.svg" alt="" srcSet="" />
              </Link>
            </span>
          </h2>
        </div>
    </>
  )
}
